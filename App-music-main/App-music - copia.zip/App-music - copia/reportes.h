#pragma once

class Reportes{

public:
    void ArtistaMasEscuchado();
    void SuscriptorMasActivo();
    void CancionMasEscuchada();
    void CantidadAccesosPorSuscriptor();
    void CantidadSuscriptoresDadosDeBaja();
    };

