#pragma once

bool hacerBackupSuscriptores();
bool recuperarBackupSuscriptores();
