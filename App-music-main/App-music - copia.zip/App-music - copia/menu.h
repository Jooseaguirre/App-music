#pragma once

void menuPrincipal();
void menuCanciones();
void menuSuscriptores();
void menuAccesos();
void menuMantenimiento();
void menuReportes();
void menuArtistas();
void menuAcceso();
void menuArtistasPorCancion();
void menuLogin();
void menuUsuario();
void menuAdministrador();
