#pragma once

class CancionManager {
public:
    void cargarCancion();
    void modificarCancion();
    void eliminarCancion();
    void mostrarCantidadCanciones();
    void listarTodas();
    void buscarPorId();
    void borrarCancion();
    void darDeAltaCancion();

};
